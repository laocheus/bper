//if (!ORYX.Plugins) 
//    ORYX.Plugins = new Object();
//
//ORYX.Plugins.VardefsEditor = Clazz.extend({
//	construct: function(facade, ownPluginData) {
//		this.facade = facade;
//		ORYX.FieldEditors["jbpmVardefsEditor"] = new ORYX.Plugins.VardefsEditor.JbpmVardefsEditorFactory(facade);
//	}
//});
//
//ORYX.Plugins.VardefsEditor.JbpmVardefsEditorFactory = Clazz.extend({
//	
//});
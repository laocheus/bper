
require 'test/unit'
require 'test_shape.rb'
require 'test_rdfrena'
require 'test_oryxrdfdoc'
require 'test_layout'